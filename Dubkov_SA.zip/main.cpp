#include <time.h>
#include "avl_tree.h"

int main(int argc,char **argv){
	int r=0;
	char *filename=nullptr, *s = nullptr;
	double t=0;
	avl_tree<student>* a;
	unsigned int p[GET_SIZE(256)]={0},p_all[GET_SIZE(256)]={0};

	if(!( argc==4 && sscanf(argv[1],"%d",&r)==1)){
		printf("Usage:%s r s filename\n",argv[0]);
		return 0;
	}
	s=argv[2];
	filename=argv[3];

	for(int i=0;s[i];i++)
	{
		SET_BIT(p,(unsigned char)s[i]);
	}

	t=clock();
	FILE *fp;
	if(!(fp=fopen(filename,"r"))){
		printf("Cannot open file %s\n",filename);
		return 0;
	}
	if(!(a=new avl_tree<student>)){
		printf("Cannot allocate memory\n");
		return 0;
	}
	io_status st=a->read(fp);
	switch(st){
	case io_status::eof:
		printf("Cannot open file %s\n",filename);
		break;
	case io_status::format:
		printf("Cannot read file %s\n",filename);
		break;
	case io_status::memory:
		printf("Cannot allocate memory\n");
		break;
	case io_status::open:
		break;
	case io_status::create:
		break;
	case io_status::success:
		break;
	}
	if(st!=io_status::success){
		fclose(fp);
		return 0;
	}
	fclose(fp); //прочитали дерево
	t = (clock() - t) / CLOCKS_PER_SEC;

	printf("Initialization time: %.2f\n",t);
	printf("Initial avl_tree<student>:\n");
	a->print(r);

	//решение задач
	
	const char * s_all = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
	int res_all = 0, res = 0;
	double t_all = 0;

	for(int i=0;s_all[i];i++)
	{
		SET_BIT(p_all,(unsigned char)s_all[i]);
	}

	t_all=clock();
	res_all = a->task_01(p_all);
	t_all = (clock() - t_all) / CLOCKS_PER_SEC;
	t=clock();
	res =a->task_01(p);
	t = (clock() - t) / CLOCKS_PER_SEC;
	printf ("%s : Task = %d S = %s Result = %d Elapsed = %.2f\n", argv[0], 1, s_all, res_all, t_all);
	printf ("%s : Task = %d S = %s Result = %d Elapsed = %.2f\n", argv[0], 1, s, res, t);


	t_all=clock();
	res_all = a->task_02(p_all);
	t_all = (clock() - t_all) / CLOCKS_PER_SEC;
	t=clock();
	res =a->task_02(p);
	t = (clock() - t) / CLOCKS_PER_SEC;
	printf ("%s : Task = %d S = %s Result = %d Elapsed = %.2f\n", argv[0], 2, s_all, res_all, t_all);
	printf ("%s : Task = %d S = %s Result = %d Elapsed = %.2f\n", argv[0], 2, s, res, t);


	t_all=clock();
	res_all = a->task_03(p_all);
	t_all = (clock() - t_all) / CLOCKS_PER_SEC;
	t=clock();
	res =a->task_03(p);
	t = (clock() - t) / CLOCKS_PER_SEC;
	printf ("%s : Task = %d S = %s Result = %d Elapsed = %.2f\n", argv[0], 3, s_all, res_all, t_all);
	printf ("%s : Task = %d S = %s Result = %d Elapsed = %.2f\n", argv[0], 3, s, res, t);


	t_all=clock();
	res_all = a->task_04(p_all);
	t_all = (clock() - t_all) / CLOCKS_PER_SEC;
	t=clock();
	res =a->task_04(p);
	t = (clock() - t) / CLOCKS_PER_SEC;
	printf ("%s : Task = %d S = %s Result = %d Elapsed = %.2f\n", argv[0], 4, s_all, res_all, t_all);
	printf ("%s : Task = %d S = %s Result = %d Elapsed = %.2f\n", argv[0], 4, s, res, t);


	t_all=clock();
	res_all = a->task_05(p_all);
	t_all = (clock() - t_all) / CLOCKS_PER_SEC;
	t=clock();
	res =a->task_05(p);
	t = (clock() - t) / CLOCKS_PER_SEC;
	printf ("%s : Task = %d S = %s Result = %d Elapsed = %.2f\n", argv[0], 5, s_all, res_all, t_all);
	printf ("%s : Task = %d S = %s Result = %d Elapsed = %.2f\n", argv[0], 5, s, res, t);

	delete a;
	return 0;
}


