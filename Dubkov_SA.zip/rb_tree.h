#ifndef RB_TREE_H
#define RB_TREE_H
#include <stdio.h>
#include <string.h>
#include <memory>

enum class io_status
{
	success,
	eof,
	format,
	memory,
	open,
	create,
};

enum colors
{
	invalid,
	red,
	black,
};


class student
{
private:
	std::unique_ptr<char []> name;
	int
	value = 0;
public:
	student () = default;
	student (const student& x) = delete;
// По умолчанию: переместить все поля класса - подходит
	student (student&& x) = default;
	~student () = default;
	student& operator= (const student& x) = delete;
// По умолчанию: присвоить с перемещением все поля класса - подходит
	student& operator= (student&& x) = default;
	// void print (FILE * fp = stdout) const
	// {
	// 	fprintf (fp, "%s %d\n", name.get (), value);
	// }
	void print (FILE *fp=stdout,colors color=invalid) const
	{
		if(color==red)
			fprintf(fp,"\033[1;31m%s %d\033[0m\n", name.get(), value);
		else
			fprintf(fp,"%s %d\n",name.get(),value);
	}
	io_status read (FILE * fp = stdin)
	{
		const int LEN = 1234;
		char n[LEN];
		int v;
		if (fscanf (fp, "%s%d", n, &v) != 2)
			return io_status::format;
		erase ();
		return init (n, v);
	}
	int cmp (const student& x) const
	{
// Используем переопределенную функцию сравнения с nullptr
		if (name == nullptr)
		{
			if (x.name != nullptr)
				return -1;
			return value - x.value;
		}
		if (x.name.get () == nullptr)
			return 1;
		int res = strcmp (name.get (), x.name.get ());
		if (res)
			return res;
		return value - x.value;
	}
	int operator< (const student& x) const { return cmp (x) < 0; }
	int operator<= (const student& x) const { return cmp (x) <= 0; }
	int operator> (const student& x) const { return cmp (x) > 0; }
	int operator>= (const student& x) const { return cmp (x) >= 0; }
	int operator== (const student& x) const { return cmp (x) == 0; }
	int operator!= (const student& x) const { return cmp (x) != 0; }
private:
	io_status init (const char * n, int v)
	{
		value = v;
		if (n != nullptr)
		{
			size_t len = strlen (n);
			name = std::make_unique<char []> (len + 1);
			if (name != nullptr)
			{
				for (size_t i = 0; i <= len; i++)
					name[i] = n[i];
			}
			else
				return io_status::memory;
		}
		return io_status::success;
	}
	void erase ()
	{
		value = 0;
		name.reset ();
	}
};



/////////////////////////////RB-tree///////////////////////////////////////////////
template <class T> class rb_tree;
template <class T>
class rb_tree_node : public T
{
private:
	rb_tree_node * left = nullptr;
	rb_tree_node * right = nullptr;
	rb_tree_node * parent = nullptr;
	colors color = invalid;
public:
	rb_tree_node () = default;

	rb_tree_node(const rb_tree_node& x) = delete;
	rb_tree_node(rb_tree_node&& x) : T((T&&) x)
	{
		left = nullptr;
		right = nullptr;
		parent = nullptr;
		color = invalid;
	}

	rb_tree_node& operator=(const rb_tree_node& x) = delete;
	rb_tree_node& operator=(rb_tree_node&& x)
	{
		if(this == &x)
			return this;
		(T)*this = (T&&)x;
		
		left = x.left;
		x.left = nullptr;

		right = x.right;
		x.right = nullptr;

		parent = x.parent;
		x.parent = nullptr;
	}

	friend class rb_tree<T>;
};

template <class T>
class rb_tree
{
private:
	rb_tree_node<T> * root = nullptr;
public:
	rb_tree() = default;
	~rb_tree(){
		delete_subtree(root);
	}
	io_status read (FILE * fp = stdin){
		T x;
		while(x.read(fp)==io_status::success){
			rb_tree_node<T>* curr = new rb_tree_node<T> ((rb_tree_node<T>&&)x);
			if(curr==nullptr)
				return io_status::memory;
			add_node(curr);
		}
		if(!feof(fp))
			return io_status::format;
		return io_status::success;
	}

	void add_node(rb_tree_node<T>* x)
	{
		if(root==nullptr)
		{
			x->color = black;
			x->parent = nullptr;
			x->right = nullptr;
			x->left = nullptr;
			root = x;
		}
		else{
			add_subtree(root, x);
		}
	}

	void print (int r, FILE *fp = stdout) const{
		print_subtree(root,0,r-1,fp);
	}
private:
	void delete_subtree(rb_tree_node<T>* curr)
	{
		if(curr==nullptr)
			return;
		delete_subtree(curr->left);
		delete_subtree(curr->right);
		delete curr;
	}

	static void print_subtree (rb_tree_node<T> * curr, int level, int r,FILE *fp = stdout){
		if (curr == nullptr || level > r)
			return;
		int spaces = level * 2;
		for (int i = 0; i < spaces; i++)
			printf (" ");
		if(curr->color==red)
			curr->print(fp,red);
		else
			curr->print(fp,black);
		print_subtree (curr->left, level + 1, r, fp);
		print_subtree (curr->right, level + 1, r, fp);
	}


	void add_subtree(rb_tree_node<T>* curr,rb_tree_node<T>* x){
		if(*x < *curr){
			if(curr->left==nullptr)
			{
				curr->left = x;
				x->parent = curr;
				x->color = red;
				x->left = nullptr;
				x->right = nullptr;
				fix_tree(x);
			}
			else{
				add_subtree(curr->left, x);
			}
		}
		else{
			if(curr->right==nullptr)
			{
				curr->right = x;
				x->parent = curr;
				x->color = red;
				x->left = nullptr;
				x->right = nullptr;
				fix_tree(x);
			}
			else{
				add_subtree(curr->right, x);
			}
		}
	}
	void fix_tree(rb_tree_node<T>* x)
	{
		rb_tree_node<T>* parent = nullptr, *grandparent = nullptr, *uncle = nullptr;
		while(x->parent!=nullptr && x->color==red && x->parent->color==red){
			parent = x->parent;
			grandparent = parent->parent;
			if(parent == grandparent->left){
				uncle = grandparent->right;
				if(uncle!=nullptr && uncle->color==red){
					grandparent->color = red;
					uncle->color = black;
					parent->color = black;
					x = grandparent;
				}
				else{
					if(x == parent->right){
						x = parent;
						left_rotate(x); ///rotate
					}
					else{
						parent->color = black;
						grandparent->color = red;
						right_rotate(grandparent);
						x = grandparent;
						break;
					}
				}
			}
			else{
				uncle = grandparent->left;
				if(uncle!=nullptr && uncle->color==red){
					uncle->color = black;
					parent->color = black;
					grandparent->color = red;
					x = grandparent;
				}
				else{
					if(x==parent->left)
					{
						right_rotate(parent);
						x=parent;
					}
					else{
						parent->color = black;
						grandparent->color = red;
						left_rotate(grandparent);
						x = grandparent;
						break;
					}
				}
			}
		}
		if(x->parent==nullptr)
			x->color = black;
	}

	void right_rotate(rb_tree_node<T>* curr)
	{
		rb_tree_node<T>* left = curr->left;

		curr->left=left->right;
		if(curr->left!=nullptr)
			curr->left->parent=curr;

		left->parent=curr->parent;		
		left->right=curr;		

		if(curr->parent==nullptr){
			root=left;
			curr->parent=left;
		}
		else if(curr==curr->parent->left){
			curr->parent->left=left;
			curr->parent=left;
		}
		else{
			curr->parent->right=left;
			curr->parent=left;
		}

	}
	void left_rotate(rb_tree_node<T>* curr)
	{
		rb_tree_node<T>* right=curr->right;

		curr->right=right->left;
		if(curr->right!=nullptr)
			curr->right->parent=curr;

		right->parent=curr->parent;
		right->left=curr;		

		if(curr->parent==nullptr){
			root=right;
			curr->parent=right;
		}
		else if(curr==curr->parent->right){
			curr->parent->right=right;
			curr->parent=right;
			return;
		}
		else{
			curr->parent->left=right;
			curr->parent=right;
		}
	}
	void solve_01_subtree(int k,rb_tree_node<T>* curr,int *q,int *res){
		int q_l=0,q_r=0;
		if(curr->left!=nullptr){ 
			solve_01_subtree(k,curr->left,&q_l,res);
		}
		if(curr->right!=nullptr){
			solve_01_subtree(k,curr->right,&q_r,res);
		}
		if(q_l<=k)
			(*res)+=q_l;
		if(q_r<=k)
			(*res)+=q_r;
		(*q)=q_l+q_r+1;
	}
	void solve_02_subtree(int k,rb_tree_node<T>* curr,int *q,int *d,int *res){
		int q_l=0,q_r=0,d_r=0,d_l=0;
		if(curr->left!=nullptr){ 
			solve_02_subtree(k,curr->left,&q_l,&d_l,res);
		}
		if(curr->right!=nullptr){
			solve_02_subtree(k,curr->right,&q_r,&d_r,res);
		}
		if(d_l<=k)
			(*res)+=q_l;
		if(d_r<=k)
			(*res)+=q_r;
		(*q)=q_l+q_r+1;
		*d=((d_l>d_r)?d_l:d_r)+1;
	}
	void solve_03___(rb_tree_node<T> *curr,int level,int deep,int *quantity,int* s){
		int q_l=0,q_r=0;
		if(level==deep){
			(*quantity)++;
			return;
		}
		if(curr->left) solve_03___(curr->left, level + 1, deep, quantity,&q_l);
		if(curr->right) solve_03___(curr->right, level + 1, deep, quantity,&q_r);
		*s=q_l+q_r+1;
	}
	int solve_03__(int k,rb_tree_node<T> *curr){
		int deep,quantity=-1,max=0,s=0;
		for(deep=0;quantity!=0;deep++){
			s=quantity=0;
			solve_03___(curr,0,deep,&quantity,&s);
			if(quantity>k){
				return 0;
			}
			if(max<quantity){
				max=quantity;
			}
			
		}
		if(max<=k){
			return -1;
		}
		return s;
	}
	void kolvo_node_subtree(rb_tree_node<T> *curr,int *q,int *res){
		int q_l=0,q_r=0;
		if(curr->left) kolvo_node_subtree(curr->left,&q_l,res);
		if(curr->right) kolvo_node_subtree(curr->right,&q_r,res);
		(*res)+=q_l+q_r;
		*q=q_l+q_r+1;
	}
	int kolvo_node(rb_tree_node<T>* curr){
		int res=0,q=0;
		kolvo_node_subtree(curr,&q,&res);
		return res+q;
	}
	void solve_03_subtree(int *k,int *res,rb_tree_node<T> *curr){
		int p=solve_03__(*k,curr);
		if(p==-1){
			(*res)+=kolvo_node(curr);
			return;
		}
		(*res)+=p;
		if(curr->left) solve_03_subtree(k,res,curr->left);
		if(curr->right) solve_03_subtree(k,res,curr->right);
	}
	void solve_04_subtree(int k,rb_tree_node<T> *curr,int level,int* res){
		if(level==k){
			(*res)++;
			return;
		}
		if(curr->left) solve_04_subtree(k,curr->left, level + 1,res);
		if(curr->right) solve_04_subtree(k,curr->right, level + 1, res);
		
	}
	void solve_05_subtree(int k,rb_tree_node<T> *curr,int level,int* res){
		if(level==k && curr->left==nullptr && curr->right==nullptr){
			(*res)+=level;
			return;
		}
		if(curr->left) solve_05_subtree(k,curr->left, level + 1,res);
		if(curr->right) solve_05_subtree(k,curr->right, level + 1, res);
		
	}

public:
	int solve_01(int k){
		int res=0,q=0;
		if(root!=nullptr) solve_01_subtree(k,root,&q,&res);
		if(q<=k)
			res+=q;
		return res;
	}
	int solve_02(int k){
		int res=0,q=0,d=0;
		if(root!=nullptr) solve_02_subtree(k,root,&q,&d,&res);
		if(d<=k)
			res+=q;
		return res;
	}
	int solve_03(int k){
		int res=0;	
		if(root!=nullptr) solve_03_subtree(&k,&res,root);
		return res;
	}
	int solve_04(int k){
		int res=0;	
		if(root!=nullptr) solve_04_subtree(k,root,0,&res);
		return res;
	}
	int solve_05(int k){
		int res=0;	
		if(root!=nullptr) solve_05_subtree(k,root,1,&res);
		return res;
	}

};



#endif
